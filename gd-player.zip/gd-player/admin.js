jQuery(document).ready(function($){
    $('.set_gdplayer_colors').wpColorPicker();
});
