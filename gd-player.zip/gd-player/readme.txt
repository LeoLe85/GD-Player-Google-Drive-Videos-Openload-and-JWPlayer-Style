=== GD Player For MP4 & Google Drive Videos - Openload & JWPlayer ===
Contributors: leoluanelezi
Donate link: https://ingolin.com/
Tags: GD Player, Video, Player, YouTube, Google Drive, MP4, OGG, WEBM,  Skins, Video.js, JW Player, Responsive, Mobile, iPad,
Requires at least: 3.3
Tested up to: 4.9.5
Requires PHP: 5.6
Stable tag: GD Player, Video, Player, YouTube, Google Drive, MP4, OGG, WEBM,  Skins, Video.js, JW Player, Responsive, Mobile, iPad,
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

GD Player Allows You To Play And Embed Videos With Subtitles, Self-Hosted, MP4, OGG, WebM And YouTube. In Your Post Or Page Using Shortcodes.

== Description ==

GD Player Allows You To Play And Embed Videos With Subtitles, Self-Hosted, MP4, OGG, WebM And YouTube. In Your Post Or Page Using Shortcodes. With (GD Player Pro) You Can Play Also Google Drive Videos with Subtitles. Skins-Two Types Of Player Style You Can Choose Openload Player Style Or JWPlayer Style (Skin) With GD Player You Can Set All Players Colors. GD Player Based On Video-js.

== Installation ==

1. Upload `GDPlayer.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the [GDPlayer] shortcode in your post or page using the following options.
== Insert Videos With GD Player - Shortcode Options ==
----------------------------------------------------------------------------------------------------------------------

== Google Drive Videos (Works Only With Pro Version) ==
The location of the Google Drive source for the video.

    [GDPlayer gdrive="https://drive.google.com/file/d/17La6sHdpND_sBF2nCAgxq0YUP_aYvPSA/view"]

== YouTube (Free Version) ==
The location of the YouTube source for the video.

    [GDPlayer youtube="https://www.youtube.com/watch?v=pRZqRjxkHpk"]

== MP44 (Free Version) ==
The location of the MP4 source for the video.
    
    [GDPlayer mp4="https://ingolin.com/example-video.mp4"]

== OGG (Free Version) ==
The location of the Ogg source for the video.

    [GDPlayer ogg="https://ingolin.com/example-video.ogg"]

== WEBM (Free Version) ==
The location of the WebM source for the video.

    [GDPlayer webm="https://ingolin.com/example-video.webm"]
   

== Poster (Free Version) ==
The location of the (image) poster frame for the video.

    [GDPlayer poster="https://ingolin.com/example-image.png"]

== Width ==
The width of the video.

    [GDPlayer width="640"]

== Height ==
The height of the video.

    [GDPlayer height="360"]

== Preload ==
Start loading the video as soon as possible, before the user clicks play.
Use 'auto', 'metadata', or 'none'. Auto will preload when the browser or device allows it. Metadata will load only the meta data of the video.

    [GDPlayer preload="auto"]

== Autoplay ==
Start playing the video as soon as it's ready. Use 'true' or 'false'.

    [GDPlayer autoplay="true"]

== Loop ==
Causes the video to start over as soon as it ends. Use 'true' or 'false'.

    [GDPlayer loop="true"]

== Controls ==
Use 'false' to hide the player controls.

    [GDPlayer controls="false"]

== Muted ==
Use 'true' to initially mute video.

    [GDPlayer muted="true"]
        
== id ==
Add a custom ID to your video player.

    [GDPlayer id="movie-id"]
    
== Class ==
Add a custom class to your player. Use full for floating the video player using 'alignleft' or 'alignright'.

    [GDPlayer class="alignright"]

== Tracks ==
Text Tracks are a function of HTML5 video for providing time triggered text to the viewer.

    [GDPlayer][track kind="captions" src="https://ingolin.com/example-captions.vtt" srclang="en" label="English" default="true"][/GDPlayer]

== All Attributes Example ==

    [GDPlayer mp4="https://ingolin.com/example-video.mp4" ogg="https://ingolin.com/example-video.ogg" webm="https://ingolin.com/example-video.webm" poster="https://ingolin.com/example-image.png" preload="auto" autoplay="true" width="640" height="360" id="movie-id" class="alignleft" controls="false" muted="true"][track kind="captions" src="https://ingolin.com/example-captions.vtt" srclang="en" label="English" default="true"][/GDPlayer]

----------------------------------------------------------------------------------------------------------------------

== Frequently asked questions ==

= Can this plugin to play Google Drive Videos using this plugin? =

No, To Play Google Drive Videos You Need Pro Version.

= Can I Change the player colors using this plugin? =

Yes.

= Can I embed responsive videos using this plugin? =

Yes.

= Are the videos embedded by this plugin playable on iOS devices? =

Yes.

= Can this plugin be used to embed videos in WordPress? =

Yes.

== Screenshots ==

1. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot.PNG
2. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot1.PNG
3. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot2.PNG 
4. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot3.PNG
5. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot4.PNG
6. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot5.PNG
7. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot6.PNG
8. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot7.PNG 
9. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot8.PNG
10. https://ingolin.com/gd-player-update/pluginscreenshot/screenshot9.PNG

== Changelog ==
None 

== Upgrade notice ==

We Need To update GD Player Plugin.

== Arbitrary section 1 ==

== First release ==
 1.1.1