jQuery(document).ready(function($){
    $('.GDPlayer-color-field').wpColorPicker();
});
